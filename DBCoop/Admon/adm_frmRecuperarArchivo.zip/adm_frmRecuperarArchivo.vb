﻿Imports DBCoopDL
Imports DBCoopEL.TableEntities
Imports CajaBL

Public Class adm_frmRecuperarArchivo
    Dim bl As New AdmonDLL()
    Dim blPres As New PrestamosDLL()
    Dim blApor As New AportacionesDLL()
    Dim blAho As New AhorrosDLL()
    Dim blCaja As New CajaBusiness()

    Dim dt As DataTable
    Dim fd As New FuncionesDLL
    Dim dtDescuentosEnviados As DataTable
    Dim dtDescuentosPrestamos As DataTable
    Dim dtParam As DataTable = bl.ObtieneParametros
    Dim dFecha As Date
    Dim IdAsociadoRecorrido As Integer, IdPresAnt As Integer = 0, IdMovUltAfi As Integer = 0
    Dim entAsociado As coo_Asociados
    Dim entAportaciones As New List(Of coo_Aportaciones)
    Dim entAhorros As New List(Of coo_CuentasAhorroMov)
    Dim entPrestamos As New List(Of coo_PrestamosDetalle)
    Dim elpagodetalle As New coo_PrestamosDetalle
    'Dim IdMovUlt As Integer = 0, IdMovUltApo As Integer = 0
    'Dim IdMovAho As Integer = 0, IdMovFune As Integer = 0, IdAsociadoPago As Integer = 0

    Private Sub adm_frmCierreDia_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        objCombos.adm_Sucursales(leSucursal, "")
        objCombos.adm_TiposModulo(leTipoArchivo, "")
        leSucursal.EditValue = gIdSucursal
        deFecha.EditValue = objFunciones.GetFechaContable(gIdSucursal)
    End Sub
    Private Sub btProceder_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btProceder.Click
        dt = bl.GetTablaDescuentos()
        Dim dtArchivo As New DataTable
        Dim dFechaContable As Date
        Dim TipoMov As Integer = 0
        Dim Numero As String

        dFechaContable = objFunciones.GetFechaContable(gIdSucursal)
        dtArchivo = ConstruirDatatable(btArchivoSucursal.EditValue, ",")

        For Each row As DataRow In dtArchivo.Rows

            Numero = bl.ExisteNumeroAsociado(row.Item(0))
            If Numero = "" Then
                MsgBox(String.Format("Codigo Asociado no existe {0} Imposible Continuar ", row.Item(0)), MsgBoxStyle.Critical, "Error Registro")
            End If

            IdAsociadoRecorrido = blApor.ExisteNumAsociado(Numero)

            If Numero <> "" And IdAsociadoRecorrido > 0 Then
                Dim entAsociadoRecorre As New coo_Asociados
                entAsociadoRecorre = objTablas.coo_AsociadosSelectByPK(IdAsociadoRecorrido)

                Dim dr As DataRow
                dr = dt.NewRow()
                dr("Numero") = row.Item(0)
                dr("Nombres") = entAsociadoRecorre.Nombres
                dr("Apellidos") = entAsociadoRecorre.Apellidos
                dr("Descuento") = row.Item(2)
                dr("IdAsociado") = IdAsociadoRecorrido
                dt.Rows.Add(dr)
            End If
        Next
        gc.DataSource = dt
    End Sub


    Private Sub btArchivoSucursal_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btArchivoSucursal.Click
        If btArchivoSucursal.Properties.ReadOnly = True Then
            Exit Sub
        End If
        OpenFile.ShowDialog()
        If OpenFile.FileName <> "OpenFileDialog1" Then
            btArchivoSucursal.Text = OpenFile.FileName
        End If
    End Sub

    Private Sub sbAplicar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles sbAplicar.Click
        If gv.DataRowCount = 0 Then
            MsgBox(String.Format("Debe de cargar el archivo a aplicar"), MsgBoxStyle.Critical)
            Exit Sub
        End If

        If MsgBox("Está seguro(a) de aplicar los descuentos, Ya no podra revertir los movimientos?", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then

            For i = 0 To gv.DataRowCount - 1 ' FOR DE LA LISTA DE LOS ASOCIADOS 
                Dim IdAsociadoRecorre As Integer = 0
                IdAsociadoRecorre = blApor.ExisteNumAsociado(gv.GetRowCellValue(i, "Numero"))
                Dim Residuo As Decimal = gv.GetRowCellValue(i, "Descuento")

                If leTipoArchivo.EditValue = 1 Then
                    dtDescuentosPrestamos = blPres.rptExtraeDescuentosPrestamos(IdAsociadoRecorre, deFecha.EditValue)

                    For k = 0 To dtDescuentosPrestamos.Rows.Count - 1

                        Dim IdPrestamo As Integer = dtDescuentosPrestamos.Rows(k).Item("IdPrestamo")
                        Dim IdAsoc As Integer = dtDescuentosPrestamos.Rows(k).Item("IdAsociado")
                        Dim Valor As Decimal = dtDescuentosPrestamos.Rows(k).Item("ValorCuota")
                        Dim SaldoInteres As Decimal = dtDescuentosPrestamos.Rows(k).Item("SaldoInteres")
                        Dim IdMov As Integer = dtDescuentosPrestamos.Rows(k).Item("IdMov")
                        Dim DiasCalcInteres As Integer = dtDescuentosPrestamos.Rows(k).Item("DiasCalcInteres")
                        Dim ValorDescuento As Decimal = 0.0
                        Dim entDetalle4 As New coo_PrestamosDetalle
                        Dim dtTasa As DataTable = blPres.ObtenerUltimasTasas(IdPrestamo)
                        Dim entPrestamo As New coo_Prestamos
                        Dim lUltimo As Boolean = False

                        If Residuo >= Valor Then
                            ValorDescuento = Valor
                            Residuo = Residuo - Valor
                        Else
                            ValorDescuento = Residuo
                            Residuo = 0.0
                        End If
                        If k = dtDescuentosPrestamos.Rows.Count - 1 Then
                            lUltimo = True
                        End If

                        If lUltimo = True And Residuo > 0 And blPres.GetSaldoCapitalPrestamo(IdPrestamo) > (ValorDescuento + Residuo) Then
                            ValorDescuento = ValorDescuento + Residuo
                            Residuo = 0.0
                        End If

                        entPrestamo = objTablas.coo_PrestamosSelectByPK(IdPrestamo)

                        If ValorDescuento > 0 Then
                            If SaldoInteres > ValorDescuento Then
                                With entDetalle4
                                    .IdPrestamo = entPrestamo.IdPrestamo
                                    .IdMov = IdMov + 1
                                    .Numero = "PLA-" & Format(deFecha.EditValue, "ddMMyyyy")
                                    .Fecha = deFecha.EditValue
                                    .TipoAplicacion = 1
                                    .FechaContable = objFunciones.GetFechaContable(gIdSucursal)
                                    .ImportePagado = ValorDescuento
                                    .CapitalPagado = 0.0
                                    .SaldoCapital = blPres.GetSaldoCapitalPrestamo(IdPrestamo)
                                    .DiasCalcInteres = DiasCalcInteres
                                    .DiasCalcMora = 0
                                    .InteresPagado = ValorDescuento
                                    .InteresPendiente = SaldoInteres - ValorDescuento
                                    .InteresMoraPagado = 0.0
                                    .InteresMoraPendiente = 0.0
                                    .ValorSeguroPagado = 0.0
                                    .ValorSeguroPendiente = 0.0
                                    .ManejoPagado = 0.0
                                    .ManejoPendiente = 0.0
                                    .OtrosPagado = 0.0
                                    .OtrosPendiente = 0.0
                                    .CuotaAhorro = 0.0
                                    .CuotaAportacion = 0.0
                                    .TasaInteres = dtTasa.Rows(0).Item("TasaInteres")
                                    .TasaInteresMora = dtTasa.Rows(0).Item("TasaInteresMora")
                                    .IdFormaPago = 4
                                    .IdSucursal = gIdSucursal
                                    .CreadoPor = objMenu.User
                                    .FechaHoraCreacion = Now
                                End With
                            Else
                                With entDetalle4
                                    .IdPrestamo = IdPrestamo
                                    .IdMov = IdMov + 1
                                    .Numero = "PLA-" & Format(deFecha.EditValue, "ddMMyyyy")
                                    .Fecha = deFecha.EditValue
                                    .TipoAplicacion = 1
                                    .FechaContable = objFunciones.GetFechaContable(gIdSucursal)
                                    If lUltimo = True Then
                                        .ImportePagado = ValorDescuento + Residuo
                                    Else
                                        .ImportePagado = ValorDescuento
                                    End If
                                    .CapitalPagado = (ValorDescuento - SaldoInteres)
                                    .SaldoCapital = blPres.GetSaldoCapitalPrestamo(IdPrestamo) - (ValorDescuento - SaldoInteres)
                                    .DiasCalcInteres = DiasCalcInteres
                                    .DiasCalcMora = 0.0
                                    .InteresPagado = SaldoInteres
                                    .InteresPendiente = 0.0
                                    .InteresMoraPagado = 0.0
                                    .InteresMoraPendiente = 0.0
                                    .ValorSeguroPagado = 0.0
                                    .ValorSeguroPendiente = 0.0
                                    .ManejoPagado = 0.0
                                    .ManejoPendiente = 0.0
                                    .OtrosPagado = 0.0
                                    .OtrosPendiente = 0.0
                                    .CuotaAhorro = 0.0
                                    If lUltimo = True Then
                                        .CuotaAportacion = Residuo
                                    Else
                                        .CuotaAportacion = 0.0
                                    End If

                                    .TasaInteres = dtTasa.Rows(0).Item("TasaInteres")
                                    .TasaInteresMora = dtTasa.Rows(0).Item("TasaInteresMora")
                                    .IdFormaPago = 4
                                    .IdSucursal = gIdSucursal
                                    .CreadoPor = objMenu.User
                                    .FechaHoraCreacion = Now
                                End With
                            End If
                            entPrestamos.Add(entDetalle4)
                        End If
                    Next

                    If Residuo > 0.0 Then
                        '' Descuento el diferencial de las cuotas de prestamo a las aportaciones
                        Dim entDetalleApo As New coo_Aportaciones
                        With entDetalleApo
                            .IdAsociado = IdAsociadoRecorre
                            .IdMov = blApor.GetUltMovAporta(IdAsociadoRecorre) + 1
                            .IdTipo = 1
                            .NumeroDoc = "PLA-" & Format(deFecha.EditValue, "ddMMyyyy")
                            .Fecha = deFecha.EditValue
                            .IdFormaPago = 4
                            .Cargo = 0.0
                            .Abono = Residuo
                            .Saldo = blApor.GetSaldoAporta(IdAsociadoRecorre) + Residuo
                            .LineaLibreta = blApor.GetUltLineaAporta(IdAsociadoRecorre) + 1
                            .Impreso = False
                            .IdSucursal = gIdSucursal
                            .FechaContable = objFunciones.GetFechaContable(gIdSucursal)
                            .CreadoPor = objMenu.User
                            .FechaHoraCreacion = Now
                        End With
                        entAportaciones.Add(entDetalleApo)
                    End If
                End If

                If leTipoArchivo.EditValue = 2 Then
                    If Residuo > 0.0 Then
                        '' Descuento el diferencial de las cuotas de prestamo a las aportaciones
                        Dim entDetalleApo As New coo_Aportaciones
                        With entDetalleApo
                            .IdAsociado = IdAsociadoRecorre
                            .IdMov = blApor.GetUltMovAporta(IdAsociadoRecorre) + 1
                            .IdTipo = 1
                            .NumeroDoc = "PLA-" & Format(deFecha.EditValue, "ddMMyyyy")
                            .Fecha = deFecha.EditValue
                            .IdFormaPago = 4
                            .Cargo = 0.0
                            .Abono = Residuo
                            .Saldo = blApor.GetSaldoAporta(IdAsociadoRecorre) + Residuo
                            .LineaLibreta = blApor.GetUltLineaAporta(IdAsociadoRecorre) + 1
                            .Impreso = False
                            .IdSucursal = gIdSucursal
                            .FechaContable = objFunciones.GetFechaContable(gIdSucursal)
                            .CreadoPor = objMenu.User
                            .FechaHoraCreacion = Now
                        End With
                        entAportaciones.Add(entDetalleApo)
                    End If
                End If
            Next

            Dim msj As String = ""


            msj = blPres.InsertaDescuentos(entAportaciones _
            , entAhorros, entPrestamos, 1, objFunciones.GetFechaContable(gIdSucursal), objMenu.User)

            If msj = "" Then
                MsgBox("Los Descuentos han sido guardados con éxito", MsgBoxStyle.Information)
            Else
                MsgBox(String.Format("No fue posible actualizar los Descuentos{0}{1}", Chr(13), msj), MsgBoxStyle.Critical)
                Return
            End If

            Close()


        End If
    End Sub

    Private Sub ActualizaPrestamo(ByVal Abono As Decimal, ByVal IdPrestamo As Integer)
        'blPrestamo = New Prestamo
        'Dim entPrestamoCuota As coo_Prestamos

        'entPrestamoCuota = objTablas.coo_PrestamosSelectByPK(IdPrestamo)
        'blPrestamo.FechaAmortizacion = deFecha.EditValue
        'blPrestamo.CargaPrestamo(IdPrestamo)
        'Dim entLineas As coo_Lineas = objTablas.coo_LineasSelectByPK(entPrestamoCuota.IdLinea)

        'If blPrestamo.IdAsociado <> 0 Then
        '    With blPrestamo
        '        .FechaContable = blCaja.GetFechaContable(leSucursal.EditValue)
        '        .FechaAmortizacion = deFecha.EditValue
        '        .DiasPorAnio = giDiasPorAnioPrestamo
        '        .CancelarEfectivo = False
        '        .Efectivo = entLineas.TipoLinea = 1
        '        entPrestamoCuota = objTablas.coo_PrestamosSelectByPK(blPrestamo.IdPrestamo)
        '        'Cuota base para el calculo de la mora
        '        .CalculaUltimoPago()
        '        .CalculaCuotaBaseMora()
        '        .CalculaCuotaDeberSer()
        '        'TODO cambiar nombre
        '        .ImporteAbonoPago = Abono


        '        .ComisionCobranza = 0.0
        '        .Gestion = 0.0
        '        .CuotaAportacion = entPrestamoCuota.CuotaAportacion
        '        .CuotaAhorro = entPrestamoCuota.CuotaAhorro
        '        .CuotaManejo = 0.0
        '        .NoInteres = False
        '        .CalculaAmortizacion()

        '        With elpagodetalle

        '            If blPrestamo.PagoActual.FormaPago = 4 Then
        '                .TipoAplicacion = 2
        '            Else
        '                .TipoAplicacion = 1
        '            End If

        '            .CapitalPagado = blPrestamo.PagoActual.ImporteCapital
        '            .CreadoPor = blPrestamo.CodUsuario
        '            .ComisionCobranza = blPrestamo.PagoActual.ImporteComisionCobranza
        '            .Gestion = blPrestamo.PagoActual.ImporteGestion
        '            .CuotaAhorro = blPrestamo.PagoActual.ImporteCuotaAhorro
        '            .CuotaAportacion = blPrestamo.PagoActual.ImporteCuotaAportacion
        '            .DiasCalcInteres = blPrestamo.PagoActual.DiasCalculoInteres
        '            .DiasCalcMora = blPrestamo.PagoActual.DiasCalculoMora
        '            .Fecha = blPrestamo.FechaAmortizacion
        '            .FechaContable = objFunciones.GetFechaContable(gIdSucursal)
        '            .FechaHoraCreacion = Now
        '            .IdFormaPago = blPrestamo.PagoActual.FormaPago
        '            .IdMov = blPrestamo.GetUltMovPrestamo(IdPrestamo)

        '            .IdPrestamo = blPrestamo.IdPrestamo
        '            .IdSucursal = blPrestamo.IdSucursal
        '            .ImportePagado = blPrestamo.ImporteAbonoPago

        '            'If blPrestamo.TipoCuota = 1 Then
        '            '    .InteresPagado = blPrestamo.PagoActual.ImporteInteres
        '            'Else
        '            '    Dim dtSaldos As DataTable = blCaja.CalculaSaldoPres(blPrestamo.IdPrestamo, blPrestamo.IdAsociado, deFecha.EditValue)
        '            '    .InteresPagado = SiEsNulo(dtSaldos.Rows(0).Item("SaldoInteres"), 0.0)
        '            'End If

        '            .InteresPagado = blPrestamo.PagoActual.ImporteInteres
        '            .InteresMoraPagado = blPrestamo.PagoActual.ImporteMora

        '            If .InteresMoraPagado >= Abono Then
        '                .InteresPagado = 0
        '            End If

        '            .InteresMoraPendiente = blPrestamo.PagoActual.ImporteDeudaMora
        '            .TasaInteres = blPrestamo.TasaInteresAnual
        '            .TasaInteresMora = blPrestamo.TasaInteresMora
        '            '.InteresPagado = blPrestamo.PagoActual.ImporteInteres
        '            .InteresPendiente = blPrestamo.PagoActual.ImporteDeudaInteres
        '            .ManejoPagado = blPrestamo.PagoActual.ImporteCuotaManejo
        '            .ManejoPendiente = blPrestamo.PagoActual.ImporteDeudaManejo

        '            'TODO asaber que es numero
        '            .Numero = "P-" & Format(deFecha.EditValue, "ddMMyyyy")
        '            .ReferenciaPago = blPrestamo.PagoActual.ReferenciaPago

        '            .OtrosPagado = blPrestamo.PagoActual.ImporteCuotaOtros
        '            .OtrosPendiente = blPrestamo.PagoActual.ImporteDeudaOtros
        '            .SaldoCapital = blPrestamo.PagoActual.ImporteSaldo
        '            .ValorSeguroPagado = blPrestamo.PagoActual.ImporteCuotaSeguro
        '            .ValorSeguroPendiente = blPrestamo.PagoActual.ImporteDeudaSeguro

        '            'IdPresAnt = entPrestamoCuota.IdPrestamo
        '            'IdMovUlt = .IdMov
        '        End With

        '    End With
        'End If
    End Sub

End Class


